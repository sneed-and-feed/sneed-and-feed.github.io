﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.3.3)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.3.3:
- Full Uncompressed Default Viewport (1240x780): Default window opens in full uncompressed side-by-side view (1240x780, matching .braun-chassis max-width) with resizable bounds (960x600 to 2560x1440).
- Complete C++ JUCE Native Presentation Layer (BraunLookAndFeel): Hardware-accelerated Dieter Rams functionalist UI rendering with 38 APVTS parameter rotary sliders, buttons, and combo boxes.
- Native DAW Host Context Menu: Support for parameter automation, MIDI learn, and automation envelopes in Ableton Live, FL Studio, Reaper, Cubase, and Bitwig.
- Real-Time Vector CRT Oscilloscope & Level Meters: 48 kHz phosphor vector waveform visualizer and stereo RMS peak level meters with hardware power indicator and MIDI activity monitors.
- Persistent Dual-Mode GUI Switching: Seamless runtime switching between Web UI and Native DAW UI (UI: NATIVE / WEB), with state persistently saved to %APPDATA%/Braun/AS42_settings.xml.
- Context Menu Hardening: Right-click Chromium/Edge context menu suppression in Web view to eliminate inadvertent developer tool popups during performance.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/
