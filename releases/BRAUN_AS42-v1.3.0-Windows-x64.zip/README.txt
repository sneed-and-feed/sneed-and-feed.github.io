﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.3.0)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.3.0:
- DSP Numerical Stabilization: Hardware FTZ/DAZ denormal protection, fixed biquad zero-crossing state truncation micro-clicks, and atomic APVTS thread synchronization.
- Pitch-Perfect Voice Stealing: Preserves sounding note frequency during the 5ms exponential declick fade-out, eliminating pitch-snap artifacts when notes are stolen under dense polyphony.
- Acoustic Refinement & DC Elimination: Pre-compressor 15 Hz highpass DC blocker eliminates limiter pumping from 4.55 dB down to 0.01 dB; added shimmer freeze feedback DC trap and balanced Hadamard stereo decorrelation.
- High-Performance Hot DSP Loops: Triple-angle trigonometric wavefolding (34.3% CPU reduction), precomputed FDN decay multipliers saving 384k exp() calls/sec, and power-of-2 delay bitwise buffer masking (11.2% speedup).
- Web Audio Hardening: Voice allocation de-duplication across GUI keyboard, chord clusters, and MIDI input; master panic all-notes-off recovery; zero-copy Int16Array WAV recording view pooling.
- Verified Zero-Allocation Audio Threads: 0 real-time heap allocations across polyphonic rendering blocks verified by automated test suites.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/
