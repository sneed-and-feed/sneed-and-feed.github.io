﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.2.0)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

Project & Source: https://github.com/sneed-and-feed/audio-engineering
Web Demo: https://sneed-and-feed.github.io/
