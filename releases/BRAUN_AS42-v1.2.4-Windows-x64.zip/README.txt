﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.2.4)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.2.4:
- Decoupled vector modulation touchpad from drone cutoff knobs to preserve user dial settings and calibrated preset defaults across touch, drag, latch, and spring return.
- Added bidirectional JUCE APVTS IPC bridge synchronization for vector modulation in Standalone and VST3.
- Improved reticle inverse coordinate calculation and host automation synchronization.
- Real-time C++ DSP and challenger stress testing (0 audio thread allocations).

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/