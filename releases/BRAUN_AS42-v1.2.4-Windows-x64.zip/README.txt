﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.2.4)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.2.4:
- Distinct Piano Timbre: Synthesized dedicated Felt wavetable with warm 2nd-harmonic octave presence and Lanczos windowing; purified Sine mode as a crystalline chime (0% hammer thump); connected Tone dial to resting filter cutoff.
- Natural String Decay: Struck acoustic strings decay continuously to silence with expanded 0.2x-3.5x range and filter envelope tracking.
- Standalone Vector IPC Sync: Full bidirectional parameter synchronization between 2D vector touchpad and JUCE APVTS.
- Decoupled Drone Cutoffs: Vector touchpad no longer clobbers user-dialed ladder LPF settings on touch, drag, latch, or spring-return.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/