BRAUN AS 42 · Ambient Generative Synthesizer (v1.3.1)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.3.1:
- Acoustic Felt Hammer Re-voicing: Re-engineered hammer transient from sharp white noise burst to authentic wooden soundboard modal impulse synthesis (~135 Hz damped thump) blended with low-passed velvety felt compression, smooth 12dB lowpass damping, register-scaled cutoffs (110-220 Hz bass, 220-420 Hz mid, 550-750 Hz treble), and cushioned felt attack (4.5-6.5ms), completely eliminating typewriter clicks in favor of a warm, muted Nils Frahm / Harold Budd upright piano knock.
- Continuous Acoustic Decay & Dynamic Release: Implemented dynamic release scaling (0.14s staccato at 0.2x to 1.84s singing sustain at 3.5x) and real-time voice decay updates (updateDecay) so moving the decay dial immediately modulates ringing held notes.
- Soundboard Circulation & Sympathetic Resonance Bloom: Implemented a 512-sample circular soundboard feedback loop (~10.6ms) with soft-clipped circulation and a 250ms resonance tail counter, ensuring natural acoustic bloom after notes are released instead of premature cutoff.
- Expanded UI Decay Spectrum: Widened UI decay knob and internal filter clamps to [0.2x, 3.5x].
- Host IPC Bridge Hardening: Added fallback alias mappings in PluginEditor for feltHammer, hammer, feltDecay, decay, feltTone, tone, feltSymp, and sympathetic.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/
