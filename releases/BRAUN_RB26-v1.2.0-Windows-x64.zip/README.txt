BRAUN RB-26 · Master Studio Reverberator (v1.2.0)
=================================================
Authentic Dieter Rams Functionalist Algorithmic Space Synthesizer
Direct sibling companion to the BRAUN AS-42

[ INCLUDED IN THIS RELEASE ]
1. BRAUN_RB26.vst3  - VST3 Plugin bundle for modern DAWs (Ableton, FL Studio, Reaper, Cubase, Studio One, Bitwig)
2. BRAUN_RB26.clap  - CLAP 1.0+ Plugin for CLAP hosts (Bitwig Studio, Reaper)
3. BRAUN_RB26.exe   - Standalone desktop application with direct ASIO/WASAPI and MIDI support
4. LICENSE          - MIT License

[ INSTALLATION GUIDE ]

1. VST3 Plugin Installation:
   - Copy the entire 'BRAUN_RB26.vst3' folder into your system VST3 directory:
     C:\Program Files\Common Files\VST3\
   - Target path should look like:
     C:\Program Files\Common Files\VST3\BRAUN_RB26.vst3\Contents\...
   - In your DAW, trigger a plugin rescan:
     * Ableton Live: Preferences > Plug-Ins > Rescan Plug-Ins
     * FL Studio: Options > Manage Plugins > Find installed plugins
     * Reaper: Preferences > Plug-ins > VST > Re-scan
     * Cubase / Nuendo: Studio > VST Plug-in Manager > Rescan
     * Studio One: Options > Locations > VST Plug-Ins > Reset Blocklist / Rescan
     * Bitwig Studio: Settings > Plug-ins > Rescan

2. CLAP Plugin Installation:
   - Copy 'BRAUN_RB26.clap' directly into:
     C:\Program Files\Common Files\CLAP\

3. Standalone Desktop Application:
   - Simply double-click 'BRAUN_RB26.exe' to run without a DAW.
   - Configure your audio interface (ASIO recommended) in Settings.

[ QUICK USAGE TIP ]
- The plugin initializes in Standby mode (Power OFF) by default to protect studio monitors and prevent startup thumps.
- Click the orange circular POWER button or press 'P' to engage the audio processing engine!

Project & Source: https://github.com/sneed-and-feed/braun_rb-26
Web Audio Showcase: https://sneed-and-feed.github.io/