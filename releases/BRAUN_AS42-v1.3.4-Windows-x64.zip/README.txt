BRAUN AS 42 · Ambient Generative Synthesizer (v1.3.4)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.3.4:
- Cross-Platform Compiler Optimization Parity: Enabled aggressive release optimization flags (/O2 /fp:precise /arch:AVX2 on MSVC, -O3 -Wall -Wextra on Clang/GCC) with strict IEEE-754 NaN/Inf safety and deterministic floating-point precision.
- Sub-Bass DSP Stabilization Formalization: 6-pillar pipeline featuring phase-locking, DC-blocking (15Hz highpass), stereo monofication (pan = 0), Butterworth damping (Q = 0.7071), 140Hz lowpass ceiling, and monotonic soft-knee saturation with +4.6dB gain trim. Click-free 25ms Hann crossfade dip on mode switching.
- Predictable Polyphonic Voice-Stealing Architecture: 4-tier hierarchical allocation lifecycle (Inactive -> Released -> Pedal-Latched -> Physically Held), VoiceStealPolicy framework (default OldestNoteFirst), hardware double-strike elimination (mHammerPending), and sustain pedal churn resilience (releasePedalLatchedVoices).
- "RESET ALL" Preset Preservation: Recalibrates all 32 knobs, vector coordinates, and freeze status to the active preset or custom patch instead of forcing default, protecting sound design sessions.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/
