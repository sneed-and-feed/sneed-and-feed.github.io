﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.2.3)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.2.3:
- Elta Solar 42n twin drones default to classic free-running ambient drone mode (MIDI Track OFF).
- Dynamic pitch tracking and note-off gating easily toggled via the MIDI TRACK header button.
- Official Dieter Rams archival engineering datasheets (EN & DE) added.

Project & Source: https://github.com/sneed-and-feed/audio-engineering
Web Demo: https://sneed-and-feed.github.io/
