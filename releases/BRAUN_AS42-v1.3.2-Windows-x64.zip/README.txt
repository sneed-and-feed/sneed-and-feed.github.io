﻿BRAUN AS 42 · Ambient Generative Synthesizer (v1.3.2)
=====================================================

Included in this release:
1. BRAUN_AS42.vst3 (Bundle folder)
   - Copy the 'BRAUN_AS42.vst3' folder into:
     C:\Program Files\Common Files\VST3\
   - Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Cubase, Bitwig).

2. BRAUN_AS42.exe
   - Standalone desktop version with direct ASIO/WASAPI and hardware MIDI support.
   - Run directly, no DAW required.

What's New in v1.3.2:
- Web Audio Transient Click Discontinuity Elimination: Resolved 1-sample rectangular impulse spike caused by idle AudioParam.value persistence in WebKit/Chromium re-triggering stale gain values. Idle voices strictly anchor at 0.0 with full _hammerEndTime lifecycle tracking, preventing stale gain resurrection.
- Warm Wooden Modal Soundboard & Velvety Felt Transient Synthesis: Replaced synthetic white noise with a physically-modeled ~135 Hz damped wooden soundboard modal impulse blended with 2-pole lowpass-filtered Brownian felt texture. Tightened hammer lowpass filter transition to a 0.5 ms time constant, locking cutoffs instantly before the transient peak.
- Full Parity Across Web Audio & C++ DSP: Synchronized physical modeling parameters between native standalone/VST3 and browser Web Audio engines.
- Browser Cache Busting: Updated web deployment with module versioning (app.js?v=1.3.2) to prevent stale browser disk caching.

Project & Source: https://github.com/sneed-and-feed/braun_as-42
Web Demo: https://sneed-and-feed.github.io/
