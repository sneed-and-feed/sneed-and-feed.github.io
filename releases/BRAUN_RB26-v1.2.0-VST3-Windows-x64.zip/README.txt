BRAUN RB-26 · Master Studio Reverberator (v1.2.0) — VST3 Package
================================================================
Dieter Rams Functionalist Studio Reverb for Windows x64

[ INCLUDED IN THIS RELEASE ]
1. BRAUN_RB26.vst3  - VST3 Plugin bundle
2. LICENSE          - MIT License

[ INSTALLATION GUIDE ]
1. Copy the entire 'BRAUN_RB26.vst3' folder into your system VST3 directory:
   C:\Program Files\Common Files\VST3\
   (Target path: C:\Program Files\Common Files\VST3\BRAUN_RB26.vst3)

2. Rescan plugins in your DAW:
   - Ableton Live: Preferences > Plug-Ins > Rescan Plug-Ins
   - FL Studio: Options > Manage Plugins > Find installed plugins
   - Reaper: Preferences > Plug-ins > VST > Re-scan
   - Cubase / Nuendo: Studio > VST Plug-in Manager > Rescan
   - Studio One: Options > Locations > VST Plug-Ins > Rescan
   - Bitwig Studio: Settings > Plug-ins > Rescan

[ QUICK USAGE TIP ]
- The plugin loads in Standby mode (Power OFF) to prevent monitor pops.
- Click the orange POWER button or press 'P' to engage the reverb graph!

Project & Releases: https://github.com/sneed-and-feed/braun_rb-26/releases